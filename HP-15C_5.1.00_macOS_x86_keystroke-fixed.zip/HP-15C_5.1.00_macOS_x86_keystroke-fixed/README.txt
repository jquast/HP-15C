HP-15C Simulator 5.1.00 - keystroke fix build
=============================================

This is the official HP-15C 5.1.00 simulator with the "keystrokes lost" fix
applied.

Which file to use
-----------------
- HP-15C_5.1.00_macOS_arm_keystroke-fixed.zip  for Apple Silicon Macs
  (M1, M2, M3, M4)
- HP-15C_5.1.00_macOS_x86_keystroke-fixed.zip  for Intel Macs

Installation
------------
1. Unzip the file.
2. Drag HP-15C.app into the Applications folder.
3. Open HP-15C from Applications.

First launch
------------
The app is signed locally, not notarized by Apple. On the first launch macOS
may say:

  "Apple could not verify 'HP-15C' is free of malware..."

This is normal for an app distributed outside the App Store. Do one of these:

- Open System Settings > Privacy & Security, scroll down, click "Open Anyway",
  then confirm "Open".
- Or right-click HP-15C.app in Applications, choose Open, then click Open.

If macOS still says the app is damaged, open Terminal and run:

  xattr -dr com.apple.quarantine /Applications/HP-15C.app

Important: keep the file Contents/Resources/HP-15C.vfs inside the app.
The simulator's Tcl code is stored there.

What was fixed
--------------
The key press routine now processes the key even when the visual "pressed"
tag is still set, so fast keystrokes are no longer dropped.

The included patch file is the exact change that was applied.
